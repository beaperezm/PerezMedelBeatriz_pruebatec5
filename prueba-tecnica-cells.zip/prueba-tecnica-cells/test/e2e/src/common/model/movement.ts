export interface Movement {
  title: string;
  description?: string;
}