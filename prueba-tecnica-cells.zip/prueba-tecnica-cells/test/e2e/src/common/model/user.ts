export interface User {
  company: string;
  username: string;
  password: string;
}