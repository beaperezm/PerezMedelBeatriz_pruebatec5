import { ROUTES } from './app-routes';

(function() {
  'use strict';

  window.CellsPolymer.start({ routes: ROUTES });
}());
